from flask import Flask, render_template

app = Flask(__name__)

@app.route('/')
def home():
    products = products = [
    {'name': 'T-shirts', 'emoji': '👕', 'url': 'https://www.decathlon.ro/t/1868/tricouri-barbati'},
    {'name': 'Shorts', 'emoji': '🩳', 'url': 'https://www.decathlon.ro/t/1872/pantaloni-scurti-barbati'},
    {'name': 'Sneakers', 'emoji': '👟', 'url': 'https://www.decathlon.ro/t/1881/incaltaminte-sport'},
    {'name': 'Gym Supplements', 'emoji': '💊', 'url': 'https://www.decathlon.ro/search?Ntt=suplimente'},
    {'name': 'Towels', 'emoji': '🧺', 'url': 'https://www.decathlon.ro/search?Ntt=prosop'}
]
    return render_template('index.html', products=products)

if __name__ == '__main__':
    app.run(debug=True)